% PGBOUNCER(1) @PACKAGE_VERSION@ | Databases

## Name

pgbouncer - lightweight connection pooler for PostgreSQL
