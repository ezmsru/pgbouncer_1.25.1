% PGBOUNCER.INI(5) @PACKAGE_VERSION@ | Databases

## Name

pgbouncer.ini - configuration file for pgbouncer
